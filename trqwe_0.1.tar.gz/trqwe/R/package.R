#' trqwe
#' 
#' Performance oriented statistical metrics and utility functions in R
#' 
#' @docType package
#' @author Travers 
#' @import Rcpp
#' @importFrom Rcpp evalCpp
#' @useDynLib trqwe
#' @name trqwe
NULL  